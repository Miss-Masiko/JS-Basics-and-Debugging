// TITLE
console.log(" ----- Area Of Shapes JS Arithmetic Challenge ----- \n\n")

// Constant Variables:
const pi = 3.1419;
const half = 0.5;

// Variables for measurements

   /*
   Delete these comments and
   create your variables here..
   */


// Rectangle area calculation
   //replace with calculation code here..

// Append your rectangle answer:
console.log("The area of the given rectangle is : " );


console.log("\n");


// circle area calculation
   // replace with calculation code here..

// Append your circle answer:
console.log("The area of the given circle is : ");


console.log("\n");


// triangle area calculation
   // replace with calculation code here..

// Append your triangle answer:
console.log("The area of the given triangle is : " );